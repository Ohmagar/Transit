# -*- encoding: utf-8 -*-
#!/usr/bin/env python3

__author__ = "Nicolas Schlömer, David Windisch"
__email__ = "nicolas.schloemer@student.jade-hs, david.windisch@student.jade-hs"
__copyright__ = "Copyright 2022, Jade Hochschule"
__license__ = "GNU General Public License v3.0"
__version__ = "1.0.0"
__updated__ = "2022-05-14"

"""
Angewandtes_Programmieren_Aufg1_Grp8- is licensed under the
GNU General Public License v3.0

"""


import os
import sys
import json


class MapGermany:
    """ 
    
    This class handles the country outline drawing in one place.
    Different resolutions are loaded upon object instantiation. 
    
    Upon calling of get_map_germany() a generator is returned which
    iterates through all list entries within the geojson returned dictionary.
    If latitudinal and longitudinal bounds are relevant (something other 
                                                         than 0, 1000)
    the comparison checks to see if the first entry within the currently 
    "next()" of the for loop is within these bounds - if that is not the case,
    the next value is looked at. If it is within the bounds, the function 
    yields the shape coordinates.
    """
    def __init__(self) -> object:
        geofiles = 'geodata'
        file_path = os.path.split(sys.argv[0])[0]
        new_path = os.path.join(file_path, 'ndsw')
        geodata_dir = os.path.join(new_path, geofiles)
        file_bund = os.path.join(geodata_dir, 'bundeslaender.geojson')
        with open(file_bund, 'r', encoding='utf-8') as fp:
            self.geodata_bund = json.load(fp)
        file_bund = os.path.join(geodata_dir, 'GE_DE_0.geojson')
        with open(file_bund, 'r', encoding='utf-8') as fp:
            self.geodata_gem = json.load(fp)
        file_bund = os.path.join(geodata_dir, 'LK_DE_0.geojson')
        with open(file_bund, 'r', encoding='utf-8') as fp:
            self.geodata_lk = json.load(fp)
    
    def get_map_germany(self, relevant_lat: tuple = (0,1000), 
                              relevant_lon: tuple = (0,1000)) -> iter:
        """ The function returns a generator that iterates through the keys """
        if relevant_lat[1] == 1000:
            self.geodata = self.geodata_bund
        elif relevant_lat[1] - relevant_lat[0] > 1:
            self.geodata = self.geodata_lk
        else:
            self.geodata = self.geodata_gem
        for rel_data in self.geodata['features']:
            if rel_data['geometry']['type'] == 'Polygon':
                for key in rel_data['geometry']['coordinates']:
                    if relevant_lon[0] <= key[0][0] <= relevant_lon[1]:
                        if relevant_lat[0] <= key[0][1] <= relevant_lat[1]:
                            yield key, rel_data['properties']['GEN']
                            
            elif rel_data['geometry']['type'] == 'MultiPolygon':
                for key in rel_data['geometry']['coordinates']:
                    for subkey in key:
                        if relevant_lon[0] <= subkey[0][0] <= relevant_lon[1]:
                            if relevant_lat[0] <= subkey[0][1] <= relevant_lat[1]:
                                yield subkey, rel_data['properties']['GEN']



