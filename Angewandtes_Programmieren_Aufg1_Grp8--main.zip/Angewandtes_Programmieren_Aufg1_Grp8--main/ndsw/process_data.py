# -*- encoding: utf-8 -*-
#!/usr/bin/env python3

__author__ = "Nicolas Schlömer, David Windisch"
__email__ = "nicolas.schloemer@student.jade-hs, david.windisch@student.jade-hs"
__copyright__ = "Copyright 2022, Jade Hochschule"
__license__ = "GNU General Public License v3.0"
__version__ = "1.0.0"
__updated__ = "2022-05-14"

"""
Angewandtes_Programmieren_Aufg1_Grp8- is licensed under the
GNU General Public License v3.0

"""

import pandas
import json
from tqdm import tqdm

def create_jsonfiles(feed: str) -> None:
    """
    

    Parameters
    ----------
    feed : str
        A string representation of the currently processed GTFS 
            feed: 'sfv', 'srv', 'pnv.

    The function processed different dataframes successively for improved 
    performance during later program runs.
    
    Returns
    -------
    None 
        Processed data is written onto disk.

    """
    print('\nProcessing "stops.txt"')
    reduce_stops(feed)
    print('\nProcessing "stop_times.txt"')
    reduce_stop_times(feed)
    print('\nProcessing "routes.txt"')
    create_route_id_name_info()
    print('\nProcessing "trips.txt"')
    create_trip_id_route_service()
    return None


def reduce_stops(feed: str) -> None:
    """ Iterate through dataframe and create/extend dict entry with data """
    all_stop_ids = {}
    id_name_coord = {}
    stops = pandas.read_csv('stops.txt')
    # initialize each dict entry with list
    for stop_name in list(set(stops['stop_name'])):
        all_stop_ids[stop_name] = []
    # get row count
    max_index = stops.index.stop
    # iterate through dataframe, append relevant info to dictionaries
    for row in tqdm(stops.itertuples(), total=max_index, colour='magenta',
                    ncols=80):
        all_stop_ids[row.stop_name].append(f'{row.stop_id}_{feed}')
        id_name_coord[f'{row.stop_id}_{feed}'] = (row.stop_name, row.stop_lat, row.stop_lon)
    # write dictionaries to json files.
    with open('all_stops.json', 'w+') as fp:
        json.dump(all_stop_ids, fp, indent=4)
    with open('id_name_coord.json', 'w+') as fp:
        json.dump(id_name_coord, fp, indent=4)
    return None


def reduce_stop_times(feed: str) -> None:
    """ Iterate through dataframe and create/extend dict entry with data """
    trip_id_all_stops = {}
    stop_id_all_trips = {}
    stops = pandas.read_csv('stop_times.txt', 
                            usecols=['trip_id', 'stop_id', 'stop_sequence'])
    # initialize each dict entry with list
    for trip_id in list(set(stops['trip_id'])):
        trip_id_all_stops[trip_id] = []
    for stop_id in list(set(stops['stop_id'])):
        stop_id_all_trips[f'{stop_id}_{feed}'] = []
    # get row count 
    max_index = stops.index.stop 
    # iterare through each row in stops dataframe.
    # append stop/trip id to list in corresponding dict.
    for row in tqdm(stops.itertuples(), total=max_index, colour='magenta',
                    ncols=80):
        trip_id_all_stops[row.trip_id].append(f'{row.stop_id}_{feed}')    
        stop_id_all_trips[f'{row.stop_id}_{feed}'].append(row.trip_id)
    # write dictionaries to json files.
    with open('trip_id_all_stops.json', 'w+') as fp:
        json.dump(trip_id_all_stops, fp, indent=4)
    with open('stop_id_all_trips.json', 'w+') as fp:
        json.dump(stop_id_all_trips, fp, indent=4)
    return None
                                                    

def create_route_id_name_info() -> None:
    """ Iterate through dataframe and create dict entry with relevant data """
    agency_dict = {}
    route_id_agency_info = {}
    agency = pandas.read_csv('agency.txt', usecols=['agency_id','agency_name'])
    routes = pandas.read_csv('routes.txt')
    max_index = agency.index.stop
    for row in tqdm(agency.itertuples(), total=max_index, colour='magenta',
                    ncols=80):
        agency_dict[row.agency_id] = row.agency_name
    max_index = routes.index.stop
    for row in tqdm(routes.itertuples(), total=max_index, colour='magenta',
                    ncols=80):
        route_id_agency_info[row.route_id] = (row.agency_id,
                                              row.route_long_name,
                                              row.route_short_name,
                                              row.route_type)
    with open('route_id_agency_info.json', 'w+') as fp:
        json.dump(route_id_agency_info, fp, indent=4)
    with open('agency_dict.json', 'w+') as fp:
        json.dump(agency_dict, fp, indent=4)
    return None
    
def create_trip_id_route_service() -> None:
    """ Iterate through dataframe and create dict entry with relevant data """
    trip_id_route_service = {}
    trips = pandas.read_csv('trips.txt')
    max_index = trips.index.stop
    for row in tqdm(trips.itertuples(), total=max_index, colour='magenta',
                    ncols=80):
        trip_id_route_service[row.trip_id] = (row.route_id, row.service_id)
    with open('trip_id_route_service.json', 'w+') as fp:
        json.dump(trip_id_route_service, fp, indent=4)
    return None
    