# -*- encoding: utf-8 -*-
#!/usr/bin/env python3

__author__ = "Nicolas Schlömer, David Windisch"
__email__ = "nicolas.schloemer@student.jade-hs, david.windisch@student.jade-hs"
__copyright__ = "Copyright 2022, Jade Hochschule"
__license__ = "GNU General Public License v3.0"
__version__ = "1.0.0"
__updated__ = "2022-05-14"

"""
Angewandtes_Programmieren_Aufg1_Grp8- is licensed under the
GNU General Public License v3.0

"""

import sys
import os
import PySide6
import pandas
import json

from PySide6 import QtCore
from PySide6 import QtWidgets
from PySide6 import QtGui
from screeninfo import get_monitors

import update_data
from Transitclass import TransitData
from map_draw_module import MapGermany
from dynamic_station_frequency import StationFrequency

class MainWindow(QtWidgets.QMainWindow):
    """
    MainWindow initiates and manages all widgets in the user interface 
    """
    def __init__(self):
        super().__init__()

        # a few default values
        self.mode = 'sfv'
        self.shows_week = False
        self.map_bound_lat = (0,1000)
        self.map_bound_lon = (0,1000)
        self.selected_destination = None
        self.stop_name = None

        # window settings
        self.title = "Streckennetz Deutschland"
        self.setWindowTitle(self.title)
        self.setMinimumSize(1000, 400)
        relative_window_size = self.load_settings('window_size')
        self.resize_window(relative_window_size)

        self.vlayout_window = QtWidgets.QVBoxLayout()
        self.hlayout_view = QtWidgets.QHBoxLayout()
        self.gui_menubar()
        self.vlayout_window.addLayout(self.hlayout_view)
                   
        """ scene (map) """
        self.scene = QtWidgets.QGraphicsScene()
        scene_background = QtGui.QBrush('black', QtCore.Qt.SolidPattern)
        self.scene.setBackgroundBrush(scene_background)
        self.get_data()
        self.heat_dictionary = self.intensity.process_intensity((0, 1000), 
                                                                (0, 1000), 
                                                                True, False)
        self.map_generator_sfv = self.sfv.get_map()
        self.draw_sfv()
        self.map = Map()
        self.map.setScene(self.scene)
        self.map.setRenderHint(QtGui.QPainter.Antialiasing)
        self.map.item_name.connect(self.status_bar.showMessage)
        self.map.no_item.connect(self.status_bar.showMessage)
        self.hlayout_view.addWidget(self.map) 
        self.map.stopClicked.connect(self.draw_table) # self.draw_table
        self.resize_scene()

        """ timetable and stop info """
        stop_label = QtWidgets.QLabel("Keine Haltestelle ausgewählt")
        stop_label.setAlignment(QtCore.Qt.AlignCenter)
        self.map.stopClicked.connect(stop_label.setText)
        self.map.mapClicked.connect(self.get_mapbounds)

        self.table_view = QtWidgets.QTableView()
        self.vlayout_timetable = QtWidgets.QVBoxLayout()
        self.vlayout_timetable.addWidget(stop_label)
        self.info_label = QtWidgets.QLabel(' Zeiten nach 24 Uhr ' 
                                           'gelten für den/die Folgetag(e)')
        self.gui_select_mode_and_time()
        self.toggle_btn_sfv.setChecked(True)
        self.toggle_btn_today.setChecked(True)
        self.gui_select_destination()
        self.vlayout_timetable.addWidget(self.groupBox_smt)
        self.vlayout_timetable.addWidget(self.groupBox_sd)
        self.vlayout_timetable.addWidget(self.table_view)
        self.vlayout_timetable.addWidget(self.info_label)
        self.hlayout_view.addLayout(self.vlayout_timetable)

        window_content = QtWidgets.QWidget()
        window_content.setLayout(self.vlayout_window)
        self.setCentralWidget(window_content)

    def text_changed(self, selected_destination: str):
        """
        When changing the text in the combobox, the table is redrawn

        Parameters:
        ----------
        selected_destination: str 
            current text in the connected combobox
        """
        if selected_destination != '--Alle Ziehlbahnhöfe--':
            self.selected_destination = selected_destination
        self.draw_table(self.stop_name)

    def draw_table(self, stop_name: str):
        """
        Draw timetable of the chosen stop

        Parameters:
        ----------
        stop_name: str 
            name of the chosen stop
        """
        self.stop_name = stop_name
        if self.selected_destination == None:
            self.table_model = Timetable(self.mode, self.stop_name,
                                         self.sfv,self.srv,
                                         self.pnv, self.shows_week)
            self.combobox_destinations(self.table_model.destination_list)
            self.table_view.setModel(self.table_model)
        else:
           self.table_model = Timetable(self.mode, self.stop_name,
                                        self.sfv, self.srv,
                                        self.pnv, self.shows_week, 
                                        self.selected_destination)
           self.table_view.setModel(self.table_model)
           self.selected_destination = None 
    
    def combobox_destinations(self, destination_list: list):
        """
        Creates a dropdown menu from a list

        Parameters:
        ----------
        destination_list: list 
            list of the destinations at this stop
        """
        try:
            _list = list(set(destination_list))
            self.cb_destinations = QtWidgets.QComboBox()
            self.cb_destinations.addItem('--Alle Ziehlbahnhöfe--')
            self.cb_destinations.addItems(_list)
            self.gridLayout_sd.addWidget(self.cb_destinations, 0, 0)
            self.cb_destinations.currentTextChanged.connect(self.text_changed)
        except TypeError:
            pass       

    def toggle_btn_sfv_action(self, button: bool):
        """
        Function that is executed by pressing the button.
        Changes the route type

        Parameters:
        ----------
        button: bool 
            Toggle status of the button
        """
        self.toggle_btn_srv.setChecked(False)
        self.toggle_btn_pnv.setChecked(False)
        if button == False:
            self.toggle_btn_sfv.setChecked(True)
        self.mode = 'sfv'
        if self.stop_name != None:
            self.draw_table(self.stop_name)

    def toggle_btn_srv_action(self, button: bool):
        """
        Function that is executed by pressing the button.
        Changes the route type

        Parameters:
        ----------
        button: bool 
            Toggle status of the button
        """
        self.toggle_btn_sfv.setChecked(False)
        self.toggle_btn_pnv.setChecked(False)
        if button == False:
            self.toggle_btn_srv.setChecked(True)
        self.mode = 'srv'
        if self.stop_name != None:
            self.draw_table(self.stop_name)
    
    def toggle_btn_pnv_action(self, button: bool):
        """
        Function that is executed by pressing the button.
        Changes the route type

        Parameters:
        ----------
        button: bool 
            Toggle status of the button
        """
        self.toggle_btn_srv.setChecked(False)
        self.toggle_btn_sfv.setChecked(False)
        if button == False:
            self.toggle_btn_pnv.setChecked(True)
        self.mode = 'pnv'
        if self.stop_name != None:
            self.draw_table(self.stop_name)

    def toggle_btn_today_action(self, button: bool):
        """
        Function that is executed by pressing the button.
        Changes the time span of the connections

        Parameters:
        ----------
        button: bool 
            Toggle status of the button
        """
        self.toggle_btn_week.setChecked(False)
        if button == False:
            self.toggle_btn_today.setChecked(True)
        self.shows_week = False
        if self.stop_name != None:
            self.draw_table(self.stop_name)

    def toggle_btn_week_action(self, button: bool):
        """
        Function that is executed by pressing the button.
        Changes the time span of the connections

        Parameters:
        ----------
        button: bool 
            Toggle status of the button
        """
        self.toggle_btn_today.setChecked(False)
        if button == False:
            self.toggle_btn_week.setChecked(True)
        self.shows_week = True
        if self.stop_name != None:
            self.draw_table(self.stop_name)

    def get_mapbounds(self,lon_lat_bounds: list):
        """
        Function that is executed by pressing the button.
        Receive the min and max coordinate values of the selected area
        and draw a more resolut layer

        Parameters:
        ----------
        lon_lat_bounds: list 
            min and max coordinate values of the selected area
        """
        self.map_bound_lat = lon_lat_bounds[0]
        self.map_bound_lon = lon_lat_bounds[1]
        self.draw_more_resolut_layer()

    def draw_more_resolut_layer(self):
        """
        Draw in the selected area a more resolut layer.
        The size of the values of the map_bounds determine 
        the amount of additional details
        """
        draws_srv = True
        draws_pnv = True
        if self.map_bound_lat[1]-self.map_bound_lat[0] > 1:
            draws_pnv = False
        elif self.map_bound_lat[1]-self.map_bound_lat[0] < 1:
            draws_srv = False
        if draws_pnv:
            self.heat_dictionary = self.intensity.process_intensity(self.map_bound_lat, 
                                                                    self.map_bound_lon, 
                                                                    True, True, True)
            self.draw_map(self.sfv.get_map(self.map_bound_lat,self.map_bound_lon),
                          0.0015, self.map_bound_lat, self.map_bound_lon)
            self.draw_map(self.srv.get_map(self.map_bound_lat,self.map_bound_lon),
                          0.0015, self.map_bound_lat, self.map_bound_lon)
            self.draw_map(self.pnv.get_map(self.map_bound_lat,self.map_bound_lon),
                          0.0015, self.map_bound_lat, self.map_bound_lon)
        if draws_srv:
            self.heat_dictionary = self.intensity.process_intensity(self.map_bound_lat, 
                                                                    self.map_bound_lon, 
                                                                    True, True, False)
            self.draw_map(self.sfv.get_map(self.map_bound_lat, self.map_bound_lon),
                          0.03, self.map_bound_lat, self.map_bound_lon)
            self.draw_map(self.srv.get_map(self.map_bound_lat, self.map_bound_lon),
                          0.03, self.map_bound_lat, self.map_bound_lon)

    def gui_select_destination(self):
        """
        Adds a groupbox for the dropdown menu
        """
        self.gridLayout_sd = QtWidgets.QGridLayout()
        self.groupBox_sd = QtWidgets.QGroupBox()
        self.groupBox_sd.setLayout(self.gridLayout_sd)

    def gui_select_mode_and_time(self):
        """
        Adds a groupbox for selecting traffic type and time range
        """
        self.gridLayout_smt = QtWidgets.QGridLayout()
        self.groupBox_smt = QtWidgets.QGroupBox()
        self.toggle_btn_sfv = QtWidgets.QPushButton("Schienenfernverkehr") 
        self.toggle_btn_sfv.setCheckable(True)
        self.toggle_btn_sfv.clicked.connect(self.toggle_btn_sfv_action)
        self.toggle_btn_srv = QtWidgets.QPushButton("Schienenregionalverkehr")
        self.toggle_btn_srv.setCheckable(True)
        self.toggle_btn_srv.clicked.connect(self.toggle_btn_srv_action)
        self.toggle_btn_pnv = QtWidgets.QPushButton("Personennahverkehr")
        self.toggle_btn_pnv.setCheckable(True)
        self.toggle_btn_pnv.clicked.connect(self.toggle_btn_pnv_action)
        self.toggle_btn_today = QtWidgets.QPushButton("Heute") 
        self.toggle_btn_today.setCheckable(True)
        self.toggle_btn_today.clicked.connect(self.toggle_btn_today_action)
        self.toggle_btn_week = QtWidgets.QPushButton("Diese Woche") 
        self.toggle_btn_week.setCheckable(True)
        self.toggle_btn_week.clicked.connect(self.toggle_btn_week_action)                                     
        self.gridLayout_smt.addWidget(self.toggle_btn_sfv, 0, 0)
        self.gridLayout_smt.addWidget(self.toggle_btn_srv, 0, 1)
        self.gridLayout_smt.addWidget(self.toggle_btn_pnv, 0, 2)
        self.gridLayout_smt.addWidget(self.toggle_btn_today, 1, 0)
        self.gridLayout_smt.addWidget(self.toggle_btn_week, 1, 1)
        self.groupBox_smt.setLayout(self.gridLayout_smt)

    def gui_menubar(self):
        """
        Adds a menubar for basic settings
        """
        self.menubar = QtWidgets.QMenuBar()
        self.menubar.setEnabled(True)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 842, 21))
        self.vlayout_window.addWidget(self.menubar)
        self.menuSettings = QtWidgets.QMenu()
        self.menuSettings.setTitle('Einstellungen')
        self.menubar.addMenu(self.menuSettings)
        self.menuResize = QtGui.QAction('Karte ausrichten')
        self.menuResize.triggered.connect(self.resize_scene)
        self.menubar.addAction(self.menuResize)
        self.menuExit = QtGui.QAction('Schließen')
        self.menuExit.triggered.connect(self.close_App)
        self.menubar.addAction(self.menuExit)
        
        self.setting_window_size = QtWidgets.QMenu()
        self.setting_window_size.setTitle('Fenstergröße')
        self.menuSettings.addMenu(self.setting_window_size)
        self.window_size_fullScreen = QtGui.QAction('Vollbild')
        self.window_size_fullScreen.setCheckable(True)
        self.window_size_fullScreen.triggered.connect(self.resize_fullScreen)
        self.window_size_max = QtGui.QAction('Maximiert')
        self.window_size_max.setCheckable(True)
        self.window_size_max.triggered.connect(self.resize_max)
        self.window_size_70 = QtGui.QAction('70%')
        self.window_size_70.setCheckable(True)
        self.window_size_70.triggered.connect(self.resize_window_70)
        self.window_size_50 = QtGui.QAction('50%')
        self.window_size_50.setCheckable(True)
        self.window_size_50.triggered.connect(self.resize_window_50)
        self.setting_window_size.addAction(self.window_size_fullScreen)
        self.setting_window_size.addAction(self.window_size_max)
        self.setting_window_size.addAction(self.window_size_70)
        self.setting_window_size.addAction(self.window_size_50)
        
        self.setting_routes = QtWidgets.QMenu()
        self.setting_routes.setTitle('Strecken neu zeichnen')
        self.menuSettings.addMenu(self.setting_routes)
        self.route_sfv = QtGui.QAction('Schienenfernverkehr')
        self.route_sfv.triggered.connect(self.draw_sfv)
        self.route_srv = QtGui.QAction('Schienenregionalverkehr')
        self.route_srv.triggered.connect(self.draw_srv)
        self.route_pnv = QtGui.QAction('Öffentlicher Nahverkehr(!Warnung!)')
        self.route_pnv.triggered.connect(self.draw_pnv)
        self.setting_routes.addAction(self.route_sfv)
        self.setting_routes.addAction(self.route_srv)
        self.setting_routes.addAction(self.route_pnv)
        self.status_bar = self.statusBar()

    def get_data(self): 
        """
        Makes the data of the routes available
        """       
        current_path = os.path.split(sys.argv[0])[0] 
        os.chdir(current_path)
        update_data.download_and_extract(current_path)
        self.sfv = TransitData(current_path, 'sfv')
        self.srv = TransitData(current_path, 'srv')
        self.pnv = TransitData(current_path, 'pnv')
        self.intensity = StationFrequency(self.sfv.stop_times, 
                                          self.sfv.id_name_coord, 
                                          self.sfv.stops,
                                          self.srv.stop_times, 
                                          self.srv.id_name_coord, 
                                          self.srv.stops,
                                          self.pnv.stop_times, 
                                          self.pnv.id_name_coord, 
                                          self.pnv.stops)      

    def resize_window_70(self):
        """
        Function connected with a button that adjusts 
        the window size and saves it
        """ 
        self.setWindowState(QtCore.Qt.WindowNoState)
        self.resize_window(0.7)
        self.window_size_70.setChecked(True)
        self.window_size_50.setChecked(False)
        self.window_size_fullScreen.setChecked(False)
        self.window_size_max.setChecked(False)
        self.save_settings('window_size', 0.7)

    def resize_window_50(self):
        """
        Function connected with a button that adjusts 
        the window size and saves it
        """ 
        self.setWindowState(QtCore.Qt.WindowNoState)
        self.resize_window(0.5)
        self.window_size_70.setChecked(False)
        self.window_size_50.setChecked(True)
        self.window_size_fullScreen.setChecked(False)
        self.window_size_max.setChecked(False)
        self.save_settings('window_size', 0.5)
        
    def resize_fullScreen(self):
        """
        Function connected with a button that adjusts 
        the window size and saves it
        """ 
        self.setWindowState(QtCore.Qt.WindowFullScreen)
        self.window_size_70.setChecked(False)
        self.window_size_50.setChecked(False)
        self.window_size_fullScreen.setChecked(True)
        self.window_size_max.setChecked(False)
        self.save_settings('window_size', 0.9)

    def resize_max(self):
        """
        Function connected with a button that adjusts 
        the window size and saves it
        """ 
        self.setWindowState(QtCore.Qt.WindowMaximized)
        self.window_size_70.setChecked(False)
        self.window_size_50.setChecked(False)
        self.window_size_fullScreen.setChecked(False)
        self.window_size_max.setChecked(True)
        self.save_settings('window_size', 0.9)

    def draw_sfv(self):
        """
        Function connected with a button that 
        clears the scene and redraws the map
        """ 
        self.map_bound_lat = (0, 1000)
        self.map_bound_lon = (0, 1000)
        self.heat_dictionary = self.intensity.process_intensity(self.map_bound_lat, 
                                                                self.map_bound_lon, 
                                                                True, False, False)
        self.scene.clear()
        self.draw_map(self.sfv.get_map())
        self.route_sfv.setChecked(True)

    def draw_srv(self):
        """
        Function connected with a button that 
        clears the scene and redraws the map
        """ 
        self.map_bound_lat = (0, 1000)
        self.map_bound_lon = (0, 1000)
        self.heat_dictionary = self.intensity.process_intensity(self.map_bound_lat, 
                                                                self.map_bound_lon, 
                                                                True, True, False)
        self.scene.clear()
        self.draw_map(self.srv.get_map())
        self.route_srv.setChecked(True)

    def draw_pnv(self):
        """
        Function connected with a button that 
        clears the scene and redraws the map
        """ 
        self.map_bound_lat = (0, 1000)
        self.map_bound_lon = (0, 1000)
        self.heat_dictionary = self.intensity.process_intensity(self.map_bound_lat, 
                                                                self.map_bound_lon, 
                                                                True, True, True)
        self.scene.clear()
        self.draw_map(self.pnv.get_map())
        self.route_pnv.setChecked(True)

    def draw_map(self, map_generator: iter, 
                 circle_size: float = 0.05, 
                 bound_lat: tuple or list = (0,1000), 
                 bound_lon: tuple or list = (0,1000)):
        """
        Draws into the current scene, constrained by the specified parameters

        Parameters:
        ----------
        map_generator: iter
            a generator that contains all coordinates and names
        circle_size: float
            the size of the ellipse objekt with default 0.05
        bound_lat: tuple or list
            restriction of the list to an area by latitude
            default (0,1000)
        bound_lon: tuple or list
            restriction of the list to an area by longitude
            default(0,1000)
        """ 
        pen_germany = QtGui.QPen("grey")
        pen_germany.setWidth(0.0001)
        map_germany = MapGermany()
        m = map_germany.get_map_germany(bound_lat,bound_lon)
        for polygon in m:
            qpolygon = QtGui.QPolygonF()
            list_x = []
            list_y = []
            for x,y in polygon[0]:
                qpolygon.append(QtCore.QPointF(x, -y))
                list_x.append(x)
                list_y.append(y)
            polygon_item = self.scene.addPolygon(qpolygon, pen=pen_germany)
            polygon_item.name = polygon[1]
            polygon_long_lat = [[min(list_y), max(list_y)], 
                                [min(list_x), max(list_x)]]
            polygon_item.polygon_long_lat = polygon_long_lat

        pen_line = QtGui.QPen()
        pen_line.setWidth(0.001)
        pen_line.setColor('brown')
        pen_circle = QtGui.QPen()
        pen_circle.setWidth(0.05)
        pen_circle.setColor('green')
        brush_circle = QtGui.QBrush("black", QtCore.Qt.BrushStyle.SolidPattern)
        for route in map_generator:
            for pair in route:
                stop = pair[0][0]
                y1 = pair[0][1]
                x1 = pair[0][2]
                y2 = pair[1][1]
                x2 = pair[1][2] 
                line = self.scene.addLine(x1, -y1, x2, -y2, pen_line)
                line.no_stop = ''
                if stop in self.heat_dictionary:
                    rgb = self.heat_dictionary[stop]
                else:
                    rgb = [3, 3, 255]
                pen_circle.setColor(QtGui.QColor(rgb[0], rgb[1], rgb[2]))
                ellipse_stop = self.scene.addEllipse(x1, -y1, circle_size,
                                                     circle_size, pen_circle,
                                                     brush_circle)
                ellipse_stop.name = stop
            stop = pair[1][0]
            if stop in self.heat_dictionary:
                rgb = self.heat_dictionary[stop]
            else:
                rgb = [3, 3, 255]
            pen_circle.setColor(QtGui.QColor(rgb[0], rgb[1], rgb[2]))
            ellipse_stop = self.scene.addEllipse(x2, -y2, circle_size, 
                                                 circle_size, pen_circle,
                                                 brush_circle)
            ellipse_stop.name = stop
        print('routes drawn')

    def resize_window(self, relative_size: float):
        """
        Draws into the current scene, constrained by the specified parameters

        Parameters:
        ----------
        relative_size: float
        """ 
        if relative_size == None:
            relative_size = 0.8
        for m in get_monitors():
            pass
        self.resize(int(relative_size*m.width), int(relative_size*m.height))

    def resize_scene(self):
        """ Resets the size of the scene so that all items are visible again """
        scene_size = self.map.sceneRect()
        dx = (self.width()-400)/(scene_size.width())
        dy = (self.height()-100)/scene_size.height()
        self.map.setTransform(QtGui.QTransform.fromScale(dx, dy))

    def load_settings(self, setting: str) -> float or None:
        """
        Opens the settings file, finds the dictionary with 
        the entered parameter and returns the value

        Parameters:
        ----------
        setting: string
        """
        filename = "settings.json"
        ndsw_path = os.path.join(os.path.split(sys.argv[0])[0], 'ndsw')
        settings_path = os.path.join(ndsw_path, filename)
        if os.path.exists(settings_path) == True:
            with open(settings_path,'r') as fp:
                dictionary = json.load(fp)
                value = dictionary[setting]
            return float(value)
        else:
            return None         

    def save_settings(self, setting: str, value):
        """
        Saves a dictionary with the entered name and 
        value in the settings file
        
        Parameters:
        ----------
        setting: string
        value: any
        """
        filename = "settings.json"
        ndsw_path = os.path.join(os.path.split(sys.argv[0])[0], 'ndsw')
        settings_path = os.path.join(ndsw_path, filename)        
        dictionary = {setting:str(value)}
        with open(settings_path,'w+') as fp:
            json.dump(dictionary, fp, indent=4)

    def close_App(self):
        self.close() 
            

class Map(QtWidgets.QGraphicsView):
    """
    Class for controlling in the scene view via events
    """ 
    item_name = QtCore.Signal(str)
    stopClicked = QtCore.Signal(str)
    mapClicked = QtCore.Signal(list)
    no_item = QtCore.Signal(str)


    def __init__(self):
        super().__init__()
        self.setMouseTracking(True)
        self.previous_item = None
        self.zoomFactor = 1   

    def mouseMoveEvent(self, event):
        """ method from PySide6.QtGui.QMouseEvent """
        item = self.itemAt(event.position().toPoint())
        if self.previous_item is not None:
            try:
                self.previous_item.setBrush(
                    QtGui.QBrush("black", QtCore.Qt.BrushStyle.SolidPattern))
            except (AttributeError, RuntimeError):
                pass
            self.previous_item = None
        if item is not None:
            try:
                item.setBrush(QtGui.QBrush("red", 
                                           QtCore.Qt.BrushStyle.SolidPattern))
                self.item_name.emit(item.name)
            except AttributeError:
                self.item_name.emit(item.no_stop)
            self.previous_item = item
        else:
            self.no_item.emit('')
    
    def mousePressEvent(self, event):
        """ method from PySide6.QtGui.QMouseEvent """
        item = self.itemAt(event.position().toPoint())
        if item is None:
            pass
        else:
            try:
                self.stopClicked.emit(item.name)
            except AttributeError:
                pass
            try:
                self.mapClicked.emit(item.polygon_long_lat)
            except AttributeError:
                pass

    def wheelEvent(self, event):
        """ method from PySide6.QtGui.QWheelEvent """
        if event.angleDelta().y() > 0:
            zoom_factor = 1.1
        else:
            zoom_factor = 1 / 1.1
        view_pos = event.position()
        view_pos = QtCore.QPoint(view_pos.x(), view_pos.y())
        scene_pos = self.mapToScene(view_pos)
        self.centerOn(scene_pos)
        self.scale(zoom_factor, zoom_factor)
        delta = self.mapToScene(view_pos)-self.mapToScene(self.viewport().rect().center())
        self.centerOn(scene_pos-delta)
           
class Timetable(QtCore.QAbstractTableModel):
    destination_list = QtCore.Signal(list)
    """ Class to creates and fills a timetable based on a dataframe """ 
    def __init__(self, mode: str, 
                       stop_name: str, 
                       sfv: pandas.DataFrame, 
                       srv: pandas.DataFrame, 
                       pnv: pandas.DataFrame, 
                       shows_week: bool, 
                       destination = None) -> object:
        """
        Parameters:
        ----------
        mode: str: 'sfv','srv','pnv'
        stop_name: str
        sfv: 
        srv: 
        pnv: 
        shows_week: bool
        destination: str
        """
        super().__init__()
        
        self.dataframe = pandas.DataFrame()
        try:
            if mode == 'sfv':
                self.dataframe=sfv.get_schedule(stop_name, shows_week)
            elif mode == 'srv':
                self.dataframe=srv.get_schedule(stop_name, shows_week)
            elif mode == 'pnv':  
                self.dataframe=pnv.get_schedule(stop_name, shows_week)
            else:
                pass  
            self.dataframe = self.dataframe.loc[:,[
                'Typ', 'Linie', 'Ankunft', 'Abfahrt', 'Zielbahnhof', 'Agency']]
            self.destination_list = list(self.dataframe['Zielbahnhof'])
            self.temp_df = self.dataframe
        except KeyError:
            self.dataframe['Typ'] = '--'
            self.dataframe['Linie'] = '--'
            self.dataframe['Ankunft'] = '--'
            self.dataframe['Abfahrt'] = '--'
            self.dataframe['Zielbahnhof'] = '--'
            self.dataframe['Agency'] = '--'

        if destination != None:
            self.dataframe = self.dataframe[self.dataframe.Zielbahnhof == destination]

    def rowCount(self, parent=None):
        """ method from PySide6.QtCore.QAbstractTableModel """
        try:
            return len(self.dataframe)
        except AttributeError:
            return 1

    def columnCount(self, parent=None):
        """ method from PySide6.QtCore.QAbstractTableModel """
        return 6 
        
    def data(self, index, role=QtCore.Qt.DisplayRole):
        """ method from PySide6.QtCore.QAbstractTableModel """
        if role != QtCore.Qt.DisplayRole:
            return None
        try:
            x = self.dataframe.iloc[index.row(),index.column()]
            return str(x)
        except IndexError:
            return '--'

    def headerData(self, index, orientation, role=QtCore.Qt.DisplayRole):
        """ method from PySide6.QtCore.QAbstractTableModel """
        if role != QtCore.Qt.DisplayRole or orientation != QtCore.Qt.Orientation.Horizontal:
            return None
        return self.dataframe.columns[index]


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)

    window = MainWindow()
    window.show()

    sys.exit(app.exec())