# -*- encoding: utf-8 -*-
#!/usr/bin/env python3

__author__ = "Nicolas Schlömer, David Windisch"
__email__ = "nicolas.schloemer@student.jade-hs, david.windisch@student.jade-hs"
__copyright__ = "Copyright 2022, Jade Hochschule"
__license__ = "GNU General Public License v3.0"
__version__ = "1.0.0"
__updated__ = "2022-05-14"

"""
Angewandtes_Programmieren_Aufg1_Grp8- is licensed under the
GNU General Public License v3.0

"""


import os
import pandas
from datetime import date 
import time
import json
from tqdm import tqdm
# sfv = https://download.gtfs.de/germany/fv_free/latest.zip
# srv = https://download.gtfs.de/germany/rv_free/latest.zip
# opnv = https://download.gtfs.de/germany/nv_free/latest.zip

class TransitData():
    """
    The class handles all processing with the GTFS data sets thats strictly
    connection and transit based.
    
    """
    def __init__(self, path_of_data: str, used_data: str) -> object:
        self.new_path = os.path.join(path_of_data, used_data)
        self.transit = {'sfv':'Schienenfernverkehr',
                        'srv':'Schienenregionalverkehr',
                        'pnv': 'Oeffentlicher Personennahverkehr'}
        
        print(f'\nLoading {self.transit[used_data]}')
        
        (self.agency_dict, 
         self.name_all_stop_ids, 
         self.id_name_coord, 
         self.route_id_agency_info, 
         self.stop_id_all_trips, 
         self.trip_id_all_stops, 
         self.trip_id_route_service) = self.__fill_data_dictionaries()
    
        (self.calendar, 
         self.calendar_dates, 
         self.routes, 
         self.stop_times, 
         self.stops, 
         self.trips) = self.__fill_data_dataframes()

        self.weekday = time.strftime('%A').lower()
        self.current_date = str(date.today()).replace('-','')
        self.used_data = used_data
        
    def get_schedule(self, current_station: str, 
                           shows_week: bool) -> pandas.DataFrame:
        """
        

        Parameters
        ----------
        current_station : str
            The string represantion of the relevant stop.
        shows_week : bool
            A boolean operator, signaling if today or the whole week is 
            shown.

        Returns
        -------
        output_dataframe : TYPE
            The dataframe contains all transit rides with 
            destination name, route type, etc .

        """
        if not shows_week: 
            reduced_calendar = self.calendar[self.calendar[self.weekday] == 1]
            active_that_day = set()
            for serv_id in reduced_calendar['service_id']:
                df = self.trips[self.trips['service_id'] == serv_id]
                for unique_trip_id in list(set(df['trip_id'])):
                    active_that_day.add(unique_trip_id)
        else:
            active_that_day = set()
            
        station_data = self.name_all_stop_ids[current_station]
        relevant_stop_times = pandas.DataFrame()
        for lmnt in station_data:
            lmnt = int(lmnt[:-4])
            df = self.stop_times[self.stop_times['stop_id'] == lmnt]
            relevant_stop_times = pandas.concat([relevant_stop_times, df])
        lst_name = []
        type_lst = []
        route_lst = []
        agency_lst = []
        arr_time = []
        dep_time = []
        output_dataframe = pandas.DataFrame()
        for row in relevant_stop_times.itertuples():
            tr_id_is_relevant = True
            if not shows_week:
                if row.trip_id not in active_that_day:
                    tr_id_is_relevant = False
            if tr_id_is_relevant:
                tr_id = row.trip_id
                split_info = self.get_route_information(tr_id)
                lst_stop_name = self.get_destination(tr_id)
                lst_name.append(self.id_name_coord[lst_stop_name][0]) 
                type_lst.append(split_info[-1])
                route_lst.append(split_info[2])
                agency_lst.append(self.agency_dict[str(split_info[0])])
                arr_time.append(row.arrival_time)
                dep_time.append(row.departure_time)
        output_dataframe['Zielbahnhof'] = lst_name
        output_dataframe['Agency'] = agency_lst
        output_dataframe['Linie'] = route_lst
        output_dataframe['Ankunft'] = arr_time
        output_dataframe['Abfahrt'] = dep_time
        output_dataframe['Typ'] = type_lst
        output_dataframe.sort_values('Abfahrt', inplace=True)
        return output_dataframe

    
 
    def get_map(self, relevant_lat: tuple or list = (0,1000), 
                      relevant_lon: tuple or list = (0,1000)) -> iter:
        """
        
        Parameters
        ----------
        relevant_lat : Tuple -> float/int, optional
            Tuple[0] is the lower limit of the relevant latitude. 
            Tuple[1] is the upper limit of the relevant latitude.
            The default is (0,1000).
        relevant_lon : Tuple -> float/int, optional
            Tuple[0] is the lower limit of the relevant longitude.
            Tuple[1] is the upper limit of the relevant longitude.
            The default is (0,1000).
            
            
            
        The function generates a pairwise bundle of every unique trip within
        a given longitudinal and latitudinal bounds.

        Yields
        ------
        paired : Tuple 
            paired contains each stop on a route. Within the tuple
            each stop is paired up with the next stop, so that the drawing 
            process/handling can be sped up.
            

        """

        # filter the data so only stops in the given bounds are processed-
        if relevant_lat != (0,1000) and relevant_lon != (0,1000):
            red_stops = self.reduce_data(self.stops, 'stop_lat', 
                                         relevant_lat[0], relevant_lat[1])
            red_stops = self.reduce_data(red_stops, 'stop_lon', 
                                         relevant_lon[0], relevant_lon[1])
        else:
            red_stops = self.stops
        comparison_set = set()
        # iterate through relevant stop_ids present within given bound
        # iterate through dict entry with string(stop_id) as key: trip_ids
        # get all stop_ids to one trip_id
        # get name of stop and coordinates to each stop on that trip
        # if this route hasnt been processed, add it to set
        # yield the trip, bundled up pairwise for easier drawing.
        for stop_id in red_stops['stop_id']:
            trip_ids = self.stop_id_all_trips[f'{stop_id}_{self.used_data}']
            for trip_id in trip_ids:
                compare = self.trip_id_all_stops[str(trip_id)]
                # list comprehension in tuple to have it be created "in place"#
                # but be turned into a hashable format.
                exact_trip = tuple([tuple(self.id_name_coord[str(lmnt)]) for lmnt in compare])
                if exact_trip not in comparison_set:
                    if tuple(reversed(exact_trip)) not in comparison_set:
                        comparison_set.add(exact_trip)
                        paired = self.pairwise(exact_trip)
                        yield paired

        
    def pairwise(self, iterable: tuple or list, i: int = 2) -> tuple: 
        """
        
        Parameters
        ----------
        iterable : iterable
            An iterable that has to be "bundled up" into pairs with length i.
        i : integer, optional
            Describes the pair length. The default is 2.

        Returns
        -------
        Tuple
            Contains the bundled up data. 
            
        Ex:
            lst = ('A', 'B', 'C', 'D', 'E')
            out : (('A', 'B'), ('B', 'C'), ('C', 'D'), ('D', 'E'))

        """
        out = []
        # append list slices pairwise within given i (How many elements)
        for j in range(len(iterable)-i+1):
            out.append(iterable[j:j+i])
        # return tuple instead of list to minimize the memory cost
        return tuple(out)

    def type_of_transportation(self, route_type: int) -> str:
        """
        

        Parameters
        ----------
        route_type : Int
            Route_type is an identifier according to:
                http://gtfs.org/schedule/reference/#routestxt
        

        Returns
        -------
        Str
            A human-readable description of the used type of transportation.

        """
        relevant_type = {0: 'Tram/Streetcar/Lightrail', 
                         1: 'Metro/Subway',
                         2: 'Train',
                         3: 'Bus',
                         4: 'Ferry',
                         5: 'Cable Tram',
                         6: 'Aerial Lift',
                         7: 'Funicular',
                         11: 'Trolleybus',
                         12: 'Monorail'}
        return relevant_type[route_type]


               
        
    def get_destination(self, trip_id: int) -> int:
        """ The function returns the last stop on a given trip_id """
        return self.trip_id_all_stops[str(trip_id)][-1]
    
    
    def get_route_information(self, trip_id: int) -> list:
        """
        
        Parameters
        ----------
        trip_id : int or pandas Series
            A identifier for an exact route among the relevant data set.

        Returns
        -------
        List
            The route_information value with the route_id key.
            Consists of: (agency_id, long_name, short_name, route_type)
                
        """

        route_id = self.trip_id_route_service[str(trip_id)][0]
        route_information = self.route_id_agency_info[str(route_id)]
        r_type = self.type_of_transportation(route_information[-1])
        route_information = route_information[:-1] + [r_type]
        return tuple(route_information)
    
    def reduce_data(self, data_entry: pandas.DataFrame, 
                          column: str, 
                          lower_limit: str or float, 
                          upper_limit: str or float) -> pandas.DataFrame:
        """

        Parameters
        ----------
        data_entry : pandas.DataFrame
            The DataFrame contains the whole dataframe that has to be reduced.
        column : String
            Columns contains information about the columns in which lower and
            upper bounds are relevant.
        lower_limit : Int, Float
            Minimum value the data is filtered to.
        upper_limit : Int, Float
            Maximum value the data is filtered to.

        Returns
        -------
        reduced_data : DataFrame
            The dataframe contains all of the data from the original dataframe
            which falls between the lower and upper limits. 

        """
        reduced_data = data_entry[data_entry[column] >= lower_limit]
        reduced_data = reduced_data[reduced_data[column] <= upper_limit]
        return reduced_data
    
    # def get_stop_id(self, station_name):
        # return f'{self.name'
    def data_dir(self, name_of_file: str) -> str:
        """ The function returns the exact path pointing to the file """
        return os.path.join(self.new_path, name_of_file)
    
    def __fill_data_dictionaries(self) -> tuple:
        """ Helper function to quickly load the necessary json files """
        datapairs = [[{}, 'agency_dict.json'], 
                     [{}, 'all_stops.json'],
                     [{}, 'id_name_coord.json'],
                     [{}, 'route_id_agency_info.json'],
                     [{}, 'stop_id_all_trips.json'],
                     [{}, 'trip_id_all_stops.json'],
                     [{}, 'trip_id_route_service.json']]
        
        for datapair in tqdm(datapairs, total=7, colour='magenta', ncols=80):
            with open(self.data_dir(datapair[1]), 'r') as f:
                datapair[0] = json.load(f)
        return (datapairs[0][0], 
                datapairs[1][0], 
                datapairs[2][0], 
                datapairs[3][0], 
                datapairs[4][0], 
                datapairs[5][0],
                datapairs[6][0])
    
    def __fill_data_dataframes(self) -> tuple:
        """ Helper function to quickly load the necessary csv files """
        datapairs = [[[], 'calendar.txt'], 
                     [[], 'calendar_dates.txt'],
                     [[], 'routes.txt'],
                     [[], 'stop_times.txt'],
                     [[], 'stops.txt'],
                     [[], 'trips.txt']]
        
        for datapair in tqdm(datapairs, total=6, colour='magenta', ncols=80):
            datapair[0] = pandas.read_csv(self.data_dir(datapair[1]))
        return (datapairs[0][0], 
                datapairs[1][0], 
                datapairs[2][0], 
                datapairs[3][0], 
                datapairs[4][0], 
                datapairs[5][0])
        