# -*- encoding: utf-8 -*-
#!/usr/bin/env python3

__author__ = "Nicolas Schlömer, David Windisch"
__email__ = "nicolas.schloemer@student.jade-hs, david.windisch@student.jade-hs"
__copyright__ = "Copyright 2022, Jade Hochschule"
__license__ = "GNU General Public License v3.0"
__version__ = "1.0.0"
__updated__ = "2022-05-14"

"""
Angewandtes_Programmieren_Aufg1_Grp8- is licensed under the
GNU General Public License v3.0

"""

import pandas

class StationFrequency:
    """
    This class handles the data science side around the transit stations.
    
    Upon initializing, the relevant data frames are given as parameters.
    -> sfv => Schienenfernverkehr: stop_times, stops as pandas.DataFrame
                                   id_name_dict as dictionary.
    -> srv => Schienenregionalverkehr: Same as sfv
    -> pnv => Oeffentlicher Personennahverkehr: Same as sfv.
    
    
    
    The method >> process_intensity << returns a dictionary which has RBG 
        values according to the intensity: Blue -> Low intensity
                                           Green -> Mid intensity
                                           Red -> High intensity
        
        Upon calling of the function, all relevant dataframes are reduced 
        to only contain stops within the given lower and upper longitudinal 
        and latitudinal limits.
        
        To simplify the processing part, all relevant parameters are appended 
        to a list.
        
        The function calls >> get_stops_at_station << which counts 
        how often each stop is within any trip. 
        
        The function calls >> create_heat_signature << which calculates the 
        amount of the average stops per station as well as the max_value
        to be able to properly assign a heat_signature to the frequency per stop.
        
    
    
    
    """
    def __init__(self, stop_times_sfv: pandas.DataFrame, 
                       id_name_dict_sfv: pandas.DataFrame, 
                       stops_sfv: pandas.DataFrame, 
                       stop_times_srv: pandas.DataFrame, 
                       id_name_dict_srv: pandas.DataFrame, 
                       stops_srv: pandas.DataFrame, 
                       stop_times_pnv: pandas.DataFrame, 
                       id_name_dict_pnv: pandas.DataFrame, 
                       stops_pnv: pandas.DataFrame) -> object:
        self.stop_times_sfv = stop_times_sfv
        self.stop_times_srv = stop_times_srv
        self.stop_times_pnv = stop_times_pnv 
        self.id_name_dict_sfv = id_name_dict_sfv
        self.id_name_dict_srv = id_name_dict_srv
        self.id_name_dict_pnv = id_name_dict_pnv
        self.stops_sfv = stops_sfv
        self.stops_srv = stops_srv
        self.stops_pnv = stops_pnv
        
        
    def process_intensity(self, relevant_lat: tuple = (0, 1000), 
                                relevant_lon: tuple = (0, 1000), 
                                has_sfv: bool = True, 
                                has_srv: bool = False, 
                                has_pnv: bool = False) -> dict:
        self.all_stops = []
        self.all_id_dicts = []
        self.all_as_str = []
        self.all_stop_times = []
        everything_loop = []
        if has_sfv:
            everything_loop.append((self.stops_sfv, self.id_name_dict_sfv, 
                                    'sfv', self.stop_times_sfv))
        if has_srv:
            everything_loop.append((self.stops_srv, self.id_name_dict_srv, 
                                    'srv', self.stop_times_srv))
        if has_pnv:
            everything_loop.append((self.stops_pnv, self.id_name_dict_pnv, 
                                    'pnv', self.stop_times_pnv))
        
        for data_set in everything_loop:
            reduced_stops = self.reduce_data(data_set[0], 'stop_lon', 
                                             relevant_lon[0], relevant_lon[1])
            reduced_stops = self.reduce_data(reduced_stops, 'stop_lat', 
                                             relevant_lat[0], relevant_lat[1])
            stops_set = set([_id for _id in reduced_stops['stop_id']])
            self.all_stops.append(stops_set)
            self.all_id_dicts.append(data_set[1])
            self.all_as_str.append(data_set[2])
            self.all_stop_times.append(data_set[3])
            
            
        self.__get_stops_at_station()
        self.__create_heat_signature()
        return self.station_heatmap
        
        
        
    def reduce_data(self, data_entry: pandas.DataFrame, 
                          column: str, 
                          lower_limit: str or float, 
                          upper_limit: str or float) -> pandas.DataFrame:
        reduced_data = data_entry[data_entry[column] >= lower_limit]
        reduced_data = reduced_data[reduced_data[column] <= upper_limit]
        return reduced_data
    
    def __get_stops_at_station(self):
        """ Iterate through all stops of each data and count its frequency """
        self.station_dict = {}
        self.station_heatmap = {}
        for id_dict, stops, feed, dataframe in zip(self.all_id_dicts, 
                                                   self.all_stops, 
                                                   self.all_as_str,
                                                   self.all_stop_times):
            for row in dataframe.itertuples():
                if row.stop_id in stops:
                    # add "_(feed)" to stop_id to account for earlier processes
                    rel_stop_name = id_dict[f'{row.stop_id}_{feed}'][0]
                    if rel_stop_name not in self.station_dict:
                        self.station_dict[rel_stop_name] = 1
                    else:
                        self.station_dict[rel_stop_name] += 1

    def __create_heat_signature(self):
        """ Iterate through every dict key and apply heat rating to it """
        max_value = max(self.station_dict.values())
        sum_values = sum(list(self.station_dict.values()))
        per_stop = sum_values / len(self.station_dict)
        lowest_freq = per_stop / 2
        second_highest = per_stop * 2
        for key in self.station_dict:
            wert = self.station_dict[key]
            if wert < lowest_freq:
                color_intensity = (wert / lowest_freq)
                heat_value = [5, int(255 * color_intensity), 255]
            elif wert < per_stop:
                color_intensity = (wert / per_stop)
                heat_value = [5, 255, (255 - int(255 * color_intensity))]
            elif wert < second_highest:
                color_intensity = (wert / second_highest)
                heat_value = [int(255 * color_intensity), 255, 5]
            else:
                color_intensity = (wert / (max_value*0.9))
                if color_intensity > 1: 
                    color_intensity = 1
                heat_value = [255, (255 - int(255 * color_intensity)), 5]
            self.station_heatmap[key] = heat_value

        