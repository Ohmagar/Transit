# -*- encoding: utf-8 -*-
#!/usr/bin/env python3

__author__ = "Nicolas Schlömer, David Windisch"
__email__ = "nicolas.schloemer@student.jade-hs, david.windisch@student.jade-hs"
__copyright__ = "Copyright 2022, Jade Hochschule"
__license__ = "GNU General Public License v3.0"
__version__ = "1.0.0"
__updated__ = "2022-05-14"

"""
Angewandtes_Programmieren_Aufg1_Grp8- is licensed under the
GNU General Public License v3.0

"""

from decors import check_for_internet, check_for_updates
import os
import requests
import zipfile
import shutil
import process_data

@check_for_updates(auto_update=True)
@check_for_internet
def download_and_extract(current_path: str):
    """
    

    Parameters
    ----------
    current_path : str
        The 'head' working directory. Is used for easier directory creation
        as well as changing of the directories.

    Returns
    -------
    None.

    """
    # sfv = Schienenfernverkehr: IC/ICE
    # srv = Schienenregionalverkehr: RE
    # pnv = Öffis: Busse, Trams, Fären etc 
    transit_dict = {'sfv': 'Downloading "Schienenfernverkehr"',
                    'srv': 'Downloading "Schienenregionalverkehr"',
                    'pnv': 'Downloading "Öffentlicher Personalverkehr"'}
    used_folders = ('sfv', 'srv', 'pnv')
    information = ('fv_free', 'rv_free', 'nv_free')
    try: 
        for sub in used_folders:
            shutil.rmtree(os.path.join(current_path, sub))
    except Exception:
        pass
    for new_folder in used_folders:
        os.mkdir(os.path.join(current_path, new_folder))
    for new_folder, dl_link in zip(used_folders, information):
        try:
            print(f'{transit_dict[new_folder]}')
            os.chdir(os.path.join(current_path, new_folder))
            latest_download = f'https://download.gtfs.de/germany/{dl_link}/latest.zip'
            latest_zip = requests.get(latest_download)
            with open('latest_gtfs.zip', 'wb') as f:
                f.write(latest_zip.content)
            latest_zip = zipfile.ZipFile('latest_gtfs.zip')
            latest_zip.extractall()
            latest_zip.close()
            os.remove('latest_gtfs.zip')
            process_data.create_jsonfiles(new_folder)
        except Exception:
            print('Something went wrong, please restart the program.')
    os.chdir(current_path)
    return None

