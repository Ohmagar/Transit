# -*- encoding: utf-8 -*-
#!/usr/bin/env python3

__author__ = "Nicolas Schlömer, David Windisch"
__email__ = "nicolas.schloemer@student.jade-hs, david.windisch@student.jade-hs"
__copyright__ = "Copyright 2022, Jade Hochschule"
__license__ = "GNU General Public License v3.0"
__version__ = "1.0.0"
__updated__ = "2022-05-14"

"""
Angewandtes_Programmieren_Aufg1_Grp8- is licensed under the
GNU General Public License v3.0

"""

import os
from datetime import date
import time
import sys
import requests
def check_for_updates(auto_update: bool = True):
    def middle_layer(func: callable):
        """
        
    
        Parameters
        ----------
        func : This decorator applies a check if the currently downloaded data 
                is the latest data. It reads one of the calendar.txt files and
                checks to see if one of the end_date data entries surpasses the
                current date. If that is the case, the applied function 
                (download_and_extract) does not have to be called. 
                If the python script is executed for the very first time, the 
                exception handling calls the function. 
    
        Returns
        -------
        func
            The decorated function is called.
    
        """
        
        def creation_date(lmnt: str) -> str:
            """ Return str repr of the time path has las been modified """
            # get time of last modification of the path
            l = os.path.getmtime(lmnt)
            # format time to be represented to something human readable
            times = time.strftime('%Y%m%d%H%M',time.localtime(l))
            return times
        def decorate(*args, **kwargs):
            if auto_update:
                print('Checking for updates.')
                current_path = os.path.split(sys.argv[0])[0]
                # subtract passed days since the start of the week from current date
                latest_date = int(time.strftime('%Y%m%d')) - date.weekday(date.today())
                # append "0001" to account for minutes.
                latest_date = str(latest_date) + '0001'
                for idx, subfolder in enumerate(('sfv', 'srv', 'pnv')):
                    new_path = os.path.join(current_path, subfolder)
                    try:
                        os.chdir(new_path)
                    except FileNotFoundError: 
                        return func(*args, **kwargs)
                    files = [f for f in os.listdir() if f.endswith('.txt')]
                    every_date = map(creation_date, files)
                    is_latest = [dates > latest_date for dates in every_date]
                    #check if every file is True or dir is empty
                    if not all(is_latest) or is_latest == []:
                        print('Downloading latest data. This might take a while.')
                        return func(*args, **kwargs)
            else: 
                return None
            print('You are on the latest data set!')
            return None
        return decorate  
    return middle_layer     

def check_for_internet(func: callable):
    """
    

    Parameters
    ----------
    func : This decorator applies a check to see if an internet connection 
            is active. If an exception would occur, the function is NOT called.
            Otherwise the decorated function is called.

    Returns
    -------
    func
        The decorated function is called.

    """
    def decorate(*args, **kwargs):
        try:
            test_url = 'https://duckduckgo.com'
            requests.get(test_url) # get() returns the contents of the website
        except Exception:
            print('Please check your internet connection.')
            return None
        return func(*args, **kwargs)
    return decorate