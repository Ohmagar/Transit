# Angewandtes_Programmieren_Aufg1_Grp8-

## Table of Contents
1. [General Info](#general-info)
2. [Requirements](#requirements)
3. [Installation and Execution](#installationandexecution)
5. [Issues and improvements](#issuesandimprovements)

### General Info
***
This programme uses data from public transport in Germany to display train and bus connections and timetables at stops. A differentiation is made between long-distance rail transport, regional rail transport and passenger transport. 
The data required for this is taken from the website https://gtfs.de/de/feeds/. For drawing the map, the coordinates were downloaded from the following website http://opendatalab.de/projects/geojson-utilities/.

When the programme is started, the long-distance rail traffic is automatically drawn together with the map of Germany at federal state level. You can see the stop and the train connections. By clicking on a federal state, the regional traffic, the counties and the additional stops are drawn. By clicking on a county, communes or cities and the local public transport are drawn.
Stops can be clicked to display the timetable. The connections are output according to the settings made with the toggle buttons. The time span can also be set via this. 
The status bar at the bottom shows which stop or area the mouse is over and highlights this area with a red colour.
The menu bar can be used to adjust the window size, which is also saved for the next time the programme is opened. In addition, the map can be redrawn if the map is overloaded with too many items.
The schedule can be filtered by destination via a drop-down menu. The filter can be removed via '--All Destination Stations--' in the drop-down menu.

The menu bar contains one sub menu and two buttons. The buttons "Karte ausrichten" resets any zoom and centers the map. "Schließen" quits and exits the program. 
"Einstellungen" has two sub menus: one to change the window size and one to re draw the map with different transit connections: Railroad far, railroad close connections and public transit.
If the window size is changed, a settings file is created from which the program reads out the size after a restart. 

If any map is re drawn, the whole scenery is cleared and re drawn from a fresh state. 
If anything is redrawn through those buttons, EVERY connection is redrawn for the whole map. 
It is not advised to draw "Öffentlicher Nahverkehr" for Germany on its own. 


In the background a whole lot is happening with the data. 
Every monday a new set of GTFS data is published. Upon opening of the program, a internal check is done to see when the relevant data (GTFS sub directories) has last been modified. After downloading, a lot of the data is looked at, filtered, regrouped and saved into json files for easier, more performant handling.


Each time a new federal state, county or city is redrawn, one of the modules performs some calculations for the amount of stops (In the drawn section), the mean stop amount and the max stop amount and chooses a heat signature for the amount of stops per stop. This is especially useful to see where rents are the highest.. :)
But in all seriousness, it is especially useful to see which stations are the most active. 



### Screenshots
![SFV-Ansicht](https://github.com/NicolasSchloemer/Angewandtes_Programmieren_Aufg1_Grp8-/blob/main/images/sfv_Oldenburg(Oldb).png)
![SRV-Ansicht von Niedersachsen](https://github.com/NicolasSchloemer/Angewandtes_Programmieren_Aufg1_Grp8-/blob/main/images/srv_niedersachsen.png)
![PNV-Ansicht von Oldeburg](https://github.com/NicolasSchloemer/Angewandtes_Programmieren_Aufg1_Grp8-/blob/main/images/pnv_Oldenburg.png)

## Requirements
***
A Pythonversion >3.9 was used for the execution and tests. This is recommended.
The packages used are listed below.

Python libraries:
- os
- time
- datetime
- sys
- json
- zipfile
- shutil

Third party libraries:
- requests
- pandas
- tqdm
- screeninfo
- PySide6

Third party libraries must be installed via ```$pip install %library%``` if not available.

If the local public transport is drawn for the whole of Germany, you should note that a large amount of working memory is required. 16 GB RAM is recommended.

## Installation and Execution
***
As long as Python and the required packages are installed, no installation is necessary. To start the programme, carry out the following steps:
```
$ git clone https://github.com/NicolasSchloemer/Angewandtes_Programmieren_Aufg1_Grp8-.git
$ cd ../path/to/the/file-directory
$ py main_run.py or python main_run.py
```

### Issues and Improvements
***
The programme is in an executable and usable state. Nevertheless, there are some points that can be improved or extended.
- weekday filtering/marking was tried, however, a mysterious problem just halted to processing inside get_schedule. Any way of printing and trying to pinpoint the exact problem just led to more confusion. Mainly because the program just randomly decided to not do anything anymore - without erroring or stopping the program execution.  
- When using multiple screens with different resolutions, the wrong size may be used for resizing the window.
- The saving of settings can be used more extensively. In addition, so far only floats are saved and not yet the correct settings such as full screen and maximised.
- The table remains until it is overwritten. A reset button could be added to reset the current settings and to clear the table.
- Arrival and departure times that go beyond 24 hours are not yet displayed correctly. Instead, it is counted up after 24 o'clock and does not start again at 0 o'clock.
- Instead of filtering the timetable only by week and day, it is also possible to filter by a time span and date
- Less code repetitions inside different modules with better/smarter path handling and parameter handling.

